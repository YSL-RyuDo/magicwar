//using UnityEngine;
//using UnityEngine.UI;
//using TMPro; // �ؽ�Ʈ�� TextMeshPro�� �� ���

//public class CharacterHealthUI : MonoBehaviour
//{
//    [Header("��� ĳ����")]
//    public CharacterHealth target;

//    [Header("UI ����")]
//    public Slider healthSlider;
//    public TextMeshProUGUI healthText; // �Ϲ� Text �� �Ÿ� Text�� ����

//    private void Start()
//    {
//        if (target == null)
//        {
//            Debug.LogError("CharacterHealthUI: Ÿ���� �������� �ʾҽ��ϴ�.");
//            enabled = false;
//            return;
//        }

//        UpdateUI();
//    }

//    private void OnEnable()
//    {
//        if (target != null)
//        {
//            target.onTakeDamage.AddListener(UpdateUI);
//            target.onHeal.AddListener(UpdateUI);
//            target.onDeath.AddListener(UpdateUI);
//        }
//    }

//    private void OnDisable()
//    {
//        if (target != null)
//        {
//            target.onTakeDamage.RemoveListener(UpdateUI);
//            target.onHeal.RemoveListener(UpdateUI);
//            target.onDeath.RemoveListener(UpdateUI);
//        }
//    }

//    public void UpdateUI()
//    {
//        if (target == null || healthSlider == null) return;

//        float ratio = (float)target.CurrentHealth / target.MaxHealth;
//        healthSlider.value = ratio;

//        if (healthText != null)
//            healthText.text = $"{target.CurrentHealth} / {target.MaxHealth}";
//    }

//}
