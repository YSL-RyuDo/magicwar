using UnityEngine;
using UnityEngine.UI;

public class CardPopupPanel : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private GameObject panel;
    [SerializeField] private Button useButton;
    [SerializeField] private Button infoButton;

    private CardData currentCard;
    private SettingSystem settingSystem;

    private void Awake()
    {
        Hide();
        settingSystem = FindFirstObjectByType<SettingSystem>();
    }

    public void Show(CardData card, Vector3 worldPos)
    {
        // ���� ī�� �ٽ� Ŭ�� �� �� �ݱ�
        if (panel.activeSelf && currentCard == card)
        {
            Hide();
            return;
        }

        currentCard = card;
        panel.SetActive(true);

        panel.transform.position = worldPos;

        useButton.onClick.RemoveAllListeners();
        infoButton.onClick.RemoveAllListeners();

        //  Use ��ư �� ���� ��ü ��� Ȱ��ȭ
        useButton.onClick.AddListener(() =>
        {
            if (settingSystem != null)
                settingSystem.EnterReplaceMode(currentCard.ID);

            Debug.Log($"[Popup] Use {currentCard.cardName} (ID={currentCard.ID}) �� ��ü ��� ����");
            Hide();
        });

        //  Info ��ư �� ������ ī�� �� ��û
        infoButton.onClick.AddListener(() =>
        {
            var network = FindFirstObjectByType<NetworkConnector>();
            if (network != null && network.IsConnected)
            {
                PKT_REQ_MAGIC_DETAIL pkt = new PKT_REQ_MAGIC_DETAIL
                {
                    cardId = currentCard.ID
                };

                network.SendPacket(
                    PacketType.RequestMagicDetail,
                    NetworkConnector.StructToBytes(pkt)
                );

                Debug.Log($"[Popup] Info {currentCard.cardName} (ID={currentCard.ID}) �� ���̳ʸ� ��û");
            }
            Hide();
        });

    }

    public void Hide()
    {
        panel.SetActive(false);
        currentCard = null;
    }
}
