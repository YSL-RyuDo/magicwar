using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

[RequireComponent(typeof(Button))]
public class CardButton : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private Image iconImage;

    [System.NonSerialized] private CardData data;   // �ܺο����� Init
    public UnityEvent<CardData> onCardClicked = new UnityEvent<CardData>();

    private Button button;

    private void Awake()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(HandleClick);
    }

    /// <summary>
    /// �ܺ� �Ŵ������� ī�� �����͸� ������ �ʱ�ȭ
    /// </summary>
    public void Init(CardData cardData)
    {
        data = cardData;
        if (iconImage != null)
            iconImage.sprite = data.cardImage;
    }

    private void HandleClick()
    {
        if (data == null)
        {
            Debug.LogWarning($"{name} Ŭ���� - CardData�� �ʱ�ȭ���� �ʾ���!");
            return;
        }

        Debug.Log($"[CardButton] ī�� Ŭ����: {data.cardName} (ID={data.ID})");
        onCardClicked?.Invoke(data);
    }
}
