using UnityEngine;

[System.Serializable]

[CreateAssetMenu(fileName = "CardData", menuName = "Card/CardData")]
public class CardData : ScriptableObject
{
    [Header("�⺻ ����")]
    public int ID;
    public string cardName;
    public Sprite cardImage;
    [TextArea] public string description;

    [Header("�߻�ü ������")]
    public GameObject playerPrefab;
    public GameObject enemyPrefab;

    [Header("ȿ�� ���")]
    public MagicEffect[] effects;
}
