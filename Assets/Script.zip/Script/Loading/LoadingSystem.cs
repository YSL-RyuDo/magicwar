using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Runtime.InteropServices;

public class LoadingSystem : MonoBehaviour
{
    private NetworkConnector network;

    [SerializeField] private Button cancelButton;

    void Awake()
    {
        Screen.SetResolution(576, 864, false);
    }


    private void Start()
    {
        network = FindFirstObjectByType<NetworkConnector>();

        if (cancelButton != null)
            cancelButton.onClick.AddListener(OnClickCancelButton);

        if (network != null)
            network.Dispatcher.Register(PacketType.ResponseMatching, OnMatchResponseBinary);

        SendMatchRequest();
    }

    private void OnClickCancelButton()
    {
        Debug.Log("[Loading] ��Ī ��� �� �κ�� ����");

        string currentUserId = SessionData.UserID;
        network.SendPacket(PacketType.CancelMatch, currentUserId);

        SceneManager.LoadScene("LobbyScene");
    }

    private void SendMatchRequest()
    {
        Debug.Log("[Loading] ��Ī ��û ����");

        string currentUserId = SessionData.UserID;
        network.SendPacket(PacketType.RequestMatching, currentUserId);
    }


    // ------------------------------
    //   ���̳ʸ� ��Ī ���� ó��
    // ------------------------------
    private void OnMatchResponseBinary(byte[] body)
    {
        if (body.Length < Marshal.SizeOf<PKT_MATCH_RESPONSE_STRUCT>())
            return;

        PKT_MATCH_RESPONSE_STRUCT pkt =
            NetworkConnector.ByteArrayToStructure<PKT_MATCH_RESPONSE_STRUCT>(body);

        if (pkt.result == 0)
        {
            Debug.Log("[Loading] ��Ī ��� ��");
            return;
        }

        if (pkt.result == 1)
        {
            SessionData.RoomID = pkt.roomId;
            SessionData.OpponentID =
                (pkt.userA == SessionData.UserID) ? pkt.userB : pkt.userA;

            SceneManager.LoadScene("GameScene");
        }

        if (pkt.result == 2)
        {
            SceneManager.LoadScene("LobbyScene");
        }
    }

}
