using UnityEngine;

public class MagicCaster : MonoBehaviour
{
    [SerializeField] private Transform firePoint;
    [SerializeField] private CardDatabase cardDB;

    public Transform FirePoint => firePoint;

    public void Cast(int cardId, Vector2 mouseWorld)
    {
        if (firePoint == null)
        {
            Debug.LogError("[MagicCaster] firePoint null");
            return;
        }

        // 1. ���� ���
        Vector2 dir =
            (mouseWorld - (Vector2)firePoint.position).normalized;

        // 2. ī�� ���� (�����տ�)
        CardData card = cardDB.GetCard(cardId);
        if (card == null)
        {
            Debug.LogError($"[MagicCaster] CardData not found id={cardId}");
            return;
        }

        // 3. ��Ÿ�� ���� (���� ����)
        CardRuntimeData stat =
            CardStatManager.Instance.GetStat(cardId);

        if (stat == null)
        {
            Debug.LogError($"[MagicCaster] RuntimeCardStat not found id={cardId}");
            return;
        }

        // 4. ����ü ����
        GameObject projectile = Instantiate(
            card.playerPrefab,
            firePoint.position,
            Quaternion.identity
        );

        MagicProjectile proj = projectile.GetComponent<MagicProjectile>();

        if (proj == null)
        {
            Debug.LogError("[MagicCaster] MagicProjectile missing");
            Destroy(projectile);
            return;
        }

        proj.Init(
            caster: gameObject,
            dir: dir,
            cardData: card,
            runtimeData: new CardRuntimeData
            {
                ID = cardId,
                attack = stat.attack,
                speed = stat.speed,
                amount = stat.amount,
                duration = stat.duration
            }
        );

    }
}
