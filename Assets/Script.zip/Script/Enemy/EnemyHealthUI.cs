//using UnityEngine;
//using UnityEngine.UI;

//public class EnemyHealthUI : MonoBehaviour
//{
//    public Slider healthSlider;
//    public Transform followTarget;
//    public Vector3 offset = new Vector3(0, 1.2f, 0);

//    void Update()
//    {
//        // ü�¹ٰ� �� ���� ����
//        if (followTarget != null)
//        {
//            transform.position = followTarget.position + offset;
//            transform.rotation = Quaternion.identity; // ȸ�� ���� (UI�� �� ���ư�)
//        }
//    }

//    public void SetHealthRatio(float ratio)
//    {
//        if (healthSlider != null)
//        {
//            healthSlider.value = ratio;
//        }
//    }
//}
