using UnityEngine;
using System;
using System.Runtime.InteropServices;
using Unity.VisualScripting.Antlr3.Runtime;

public class LobbyService : MonoBehaviour
{
    private NetworkConnector network;
    private LobbyUIController ui;

    private void Awake()
    {
        Screen.SetResolution(576, 864, false);
        network = NetworkConnector.Instance;
        ui = FindFirstObjectByType<LobbyUIController>();
    }

    private void Start()
    {
        if (network == null || !network.IsConnected)
        {
            Debug.LogError("[LobbyService] NetworkConnector not connected");
            return;
        }

        network.Dispatcher.Register(PacketType.ResponseProfile, OnProfileReceived);
        network.Dispatcher.Register(PacketType.LobbyChat, OnChatReceived);
        

        RequestProfile();
    }

    private void OnDestroy()
    {
        if (network == null) return;

        network.Dispatcher.Unregister(PacketType.ResponseProfile, OnProfileReceived);
        network.Dispatcher.Unregister(PacketType.LobbyChat, OnChatReceived);
    }

    public void RequestProfile()
    {
        byte[] body = new byte[32];
        byte[] idBytes = System.Text.Encoding.UTF8.GetBytes(SessionData.UserID);
        Array.Copy(idBytes, body, Math.Min(32, idBytes.Length));

        network.SendPacket(PacketType.RequestProfile, body);
        Debug.Log("[LobbyService] ������ ��û ����");
    }

    private void OnProfileReceived(byte[] body)
    {
        if (body.Length < Marshal.SizeOf<PKT_RES_PROFILE_DATA>())
        {
            Debug.LogError("[LobbyService] ������ ��Ŷ ũ�� ����");
            return;
        }

        PKT_RES_PROFILE_DATA profile =
            NetworkConnector.ByteArrayToStructure<PKT_RES_PROFILE_DATA>(body);

        ui.ApplyProfile(profile);

        Debug.Log($"[LobbyService] ������ ����: {profile.nickname}");
    }

    public void SendChat(string msg)
    {
        if (string.IsNullOrWhiteSpace(msg))
            return;

        byte[] body = System.Text.Encoding.UTF8.GetBytes(msg);
        network.SendPacket(PacketType.LobbyChat, body);

        Debug.Log($"[LobbyService] ä�� �۽�: {msg}");
    }

    private void OnChatReceived(byte[] body)
    {
        int size = Marshal.SizeOf<PKT_CHAT_LOBBY_DATA>();
        if (body.Length < size)
        {
            Debug.LogWarning("[LobbyService] ä�� ��Ŷ ũ�� ����");
            return;
        }

        PKT_CHAT_LOBBY_DATA chat =
            NetworkConnector.ByteArrayToStructure<PKT_CHAT_LOBBY_DATA>(body);

        Debug.Log($"[LobbyService] ä�� ����: {chat.nickname} : {chat.message}");

        ui.AddChat(chat);
    }

    

}
