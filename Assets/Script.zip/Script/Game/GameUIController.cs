using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameUIController : MonoBehaviour
{
    public static GameUIController Instance { get; private set; }

    [Header("Magic Buttons (Q W E R)")]
    [SerializeField] private Button[] magicButtons = new Button[4];
    

    [Header("Magic Icons")]
    [SerializeField] private Image[] magicIcons = new Image[4];
    [SerializeField] private Image[] cooldownMasks;

    [Header("Card Database")]
    [SerializeField] private CardDatabase cardDB;

    [Header("HP UI")]
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TextMeshProUGUI hpText;

    [SerializeField] private GameObject victoryPanel;
    [SerializeField] private GameObject defeatPanel;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        for (int i = 0; i < magicButtons.Length; i++)
        {
            int idx = i;
            magicButtons[i].onClick.AddListener(
                () => GameManager.Instance.OnMagicButtonPressed(idx)
            );
        }
    }

    private void Update()
    {
        UpdateCooldownUI();
    }

    private void UpdateCooldownUI()
    {
        for (int i = 0; i < 4; i++)
        {
            float remain =
                GameManager.Instance.GetCooldownRemain(i);

            float total =
                GameManager.Instance.GetCooldownTotal(i);

            cooldownMasks[i].fillAmount =
                total > 0f ? remain / total : 0f;
        }
    }

    public void RefreshMagicSlots()
    {
        var slots = GameManager.Instance.EquippedMagicIds;

        for (int i = 0; i < 4; i++)
        {
            CardData card = FindCard(slots[i]);

            if (card != null)
            {
                // ������ ����
                magicIcons[i].sprite = card.cardImage;
                magicIcons[i].enabled = true;

                // ��ٿ� ����ũ���� ���� �̹��� �ֱ�
                cooldownMasks[i].sprite = card.cardImage;
                cooldownMasks[i].enabled = true;

                // �ʱ⿣ ��Ÿ�� ����
                cooldownMasks[i].fillAmount = 0f;
            }
            else
            {
                magicIcons[i].enabled = false;
                cooldownMasks[i].enabled = false;
            }
        }

        Debug.Log("[GameUI] ���� ���� + ��ٿ� ����ũ ���� �Ϸ�");
    }


    private CardData FindCard(int id)
    {
        if (cardDB == null) return null;

        foreach (var card in cardDB.cards)
        {
            if (card != null && card.ID == id)
                return card;
        }
        return null;
    }

    public void UpdateHP(int current, int max)
    {
        hpSlider.maxValue = max;
        hpSlider.value = current;
        hpText.text = $"{current} / {max}";
    }

    public void ShowVictoryUI()
    {
        victoryPanel.SetActive(true);
    }

    public void ShowDefeatUI()
    {
        defeatPanel.SetActive(true);
    }

    public void OnClickReturnToLobby()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene("LobbyScene");
    }
}
