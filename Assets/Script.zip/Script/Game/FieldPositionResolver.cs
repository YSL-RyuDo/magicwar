using UnityEngine;

public enum TeamSide
{
    Bottom,
    Top
}

public class FieldPositionResolver : MonoBehaviour
{
    public Transform bottomAnchor;
    public Transform topAnchor;

    public Vector3 Resolve(TeamSide side, float x, float y)
    {
        Vector3 local = new Vector3(x, y, 0f);

        if (side == TeamSide.Top)
        {
            // Top�� ������ ������, ������ Top Anchor
            local.y = -local.y;
            local.x = -local.x;
            return topAnchor.position + local;
        }
        else
        {
            return bottomAnchor.position + local;
        }
    }
}
