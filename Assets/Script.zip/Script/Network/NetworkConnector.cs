using UnityEngine;
using System;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;

public class NetworkConnector : MonoBehaviour
{
    private TcpClient client;
    private NetworkStream stream;
    private Thread recvThread;
    private bool running;

    public PacketDispatcher Dispatcher { get; } = new();

    public static NetworkConnector Instance { get; private set; }

    // Token (Runtime + Inspector)
    [Header("Debug (Inspector)")]
    [SerializeField]
    private uint inspectorToken;   // �ν����� ǥ�ÿ�

    [SerializeField]
    private uint token;            // ���� ���� ��ū

    public uint Token
    {
        get => token;
        private set
        {
            token = value;
            inspectorToken = value;   // �ν����� �ڵ� ����
        }
    }

    private readonly ConcurrentQueue<Action> mainThreadQueue = new();

    private const int BUFFER_SIZE = 4096;
    private readonly byte[] recvBuffer = new byte[8192];
    private int recvBufferSize = 0;

    // Unity LifeCycle
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        Connect("211.247.47.240", 9000);
        //SendPacket(PacketType.PING, Array.Empty<byte>());
    }

    private void Update()
    {
        while (mainThreadQueue.TryDequeue(out var act))
            act();
    }

    public bool IsConnected => client != null && client.Connected;

    // CONNECT
    public void Connect(string ip, int port)
    {
        try
        {
            client = new TcpClient();
            client.Connect(ip, port);

            stream = client.GetStream();
            running = true;

            recvThread = new Thread(ReceiveLoop)
            {
                IsBackground = true
            };
            recvThread.Start();

            Debug.Log("[Network] ���� ���� ����");
        }
        catch (Exception ex)
        {
            Debug.LogError("[Network] ���� ����: " + ex.Message);
        }
    }

    // SEND (Raw)
    public void SendRaw(byte[] packet)
    {
        if (!IsConnected) return;

        try
        {
            stream.Write(packet, 0, packet.Length);
        }
        catch (Exception ex)
        {
            Debug.LogError("[Network] SendRaw ����: " + ex.Message);
        }
    }

    // SEND (Header + Body)
    // Header: [packetId(2)][token(4)][bodySize(2)]
    public void SendPacket(PacketType type, byte[] body)
    {
        if (!IsConnected) return;

        ushort packetId = (ushort)type;
        ushort bodySize = (ushort)(body?.Length ?? 0);

        byte[] packet = new byte[8 + bodySize];

        // packetId
        Array.Copy(BitConverter.GetBytes(packetId), 0, packet, 0, 2);

        // token
        Array.Copy(BitConverter.GetBytes(Token), 0, packet, 2, 4);

        // bodySize
        Array.Copy(BitConverter.GetBytes(bodySize), 0, packet, 6, 2);

        // body
        if (bodySize > 0)
            Array.Copy(body, 0, packet, 8, bodySize);

        SendRaw(packet);
    }

    // ���ڿ� ���ۿ�
    public void SendPacket(PacketType type, string msg)
    {
        byte[] body = System.Text.Encoding.UTF8.GetBytes(msg);
        SendPacket(type, body);
    }

    // RECEIVE LOOP
    private void ReceiveLoop()
    {
        byte[] tempBuffer = new byte[4096];

        while (running)
        {
            try
            {
                int recv = stream.Read(tempBuffer, 0, tempBuffer.Length);
                if (recv <= 0)
                    break;

                // 1. ���� ���ۿ� ����
                Buffer.BlockCopy(
                    tempBuffer, 0,
                    recvBuffer, recvBufferSize,
                    recv);

                recvBufferSize += recv;

                // 2. ��Ŷ �Ľ� ����
                while (true)
                {
                    // ��� �ּ� ũ�� üũ
                    if (recvBufferSize < 8)
                        break;

                    ushort packetId = BitConverter.ToUInt16(recvBuffer, 0);
                    uint recvToken = BitConverter.ToUInt32(recvBuffer, 2);
                    ushort bodySize = BitConverter.ToUInt16(recvBuffer, 6);

                    int totalSize = 8 + bodySize;

                    // �ٵ� ���� �� ������ ���
                    if (recvBufferSize < totalSize)
                        break;

                    // 3. �ٵ� ����
                    byte[] body = new byte[bodySize];
                    if (bodySize > 0)
                        Buffer.BlockCopy(recvBuffer, 8, body, 0, bodySize);

                    // 4. ���� ���� (���� ������ ������ ���)
                    Buffer.BlockCopy(
                        recvBuffer, totalSize,
                        recvBuffer, 0,
                        recvBufferSize - totalSize);

                    recvBufferSize -= totalSize;

                    // 5. ���� ������� ����ġ
                    mainThreadQueue.Enqueue(() =>
                    {
                        // �α��� ���� �� ��ū ����
                        if (packetId == (ushort)PacketType.LoginSuccess)
                        {
                            Token = recvToken;
                            Debug.Log($"[Network] Token ����: {Token}");
                        }

                        Dispatcher.Dispatch((PacketType)packetId, body);
                    });
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("[Network] ���� ���� ����: " + e.Message);
                break;
            }
        }

        running = false;
    }

    // STRUCT ��ȯ
    public static T ByteArrayToStructure<T>(byte[] data) where T : struct
    {
        int size = Marshal.SizeOf<T>();
        IntPtr ptr = Marshal.AllocHGlobal(size);

        Marshal.Copy(data, 0, ptr, size);
        T result = Marshal.PtrToStructure<T>(ptr);

        Marshal.FreeHGlobal(ptr);
        return result;
    }

    public static byte[] StructToBytes<T>(T str) where T : struct
    {
        int size = Marshal.SizeOf<T>();
        byte[] arr = new byte[size];

        IntPtr ptr = Marshal.AllocHGlobal(size);
        Marshal.StructureToPtr(str, ptr, true);
        Marshal.Copy(ptr, arr, 0, size);
        Marshal.FreeHGlobal(ptr);

        return arr;
    }

    public void ResetToken()
    {
        Token = 0;
        Debug.Log("[Network] Token reset to 0");
    }
}
